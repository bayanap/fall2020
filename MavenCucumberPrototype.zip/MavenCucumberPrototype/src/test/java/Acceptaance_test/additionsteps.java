
package Acceptaance_test;
import static org.junit.Assert.assertTrue;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import najah.edu.Calc;

public class additionsteps {
	int n1,n2,result;
	
	@Given("{int}and{int}")
	public void and(int x,int y) {
		n1=x;
		n2=y;
	}
	
	
	@When("i call function add")
	public void iCallFunctionAdd() {
		Calc c=new Calc();
        result=c.and(n1,n2);
	}
	
	
	@Then("i should see {int}")
	public void ishouldsee(Integer int1) {
	   assertTrue(result==8);
	}


}
