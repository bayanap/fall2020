package Acceptaance_test;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.junit.runner.RunWith;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

	public class checkoutSteps {
		private int price =0;
		
		private najah.edu.checkout checkout;
		
			// scanning_two_bananas
			@Given("the price of {string} is {int}")
		       public void thePriceOfBananas(String item, Integer price) {
			        this.price=price;}
		
		    @When("i check {int} {string}")
				public void iCheckout_Bananas(Integer iteamCount, String string) {
					checkout = new najah.edu.checkout();
					checkout.add(iteamCount,price);}

		    @Then("the total price should be {int}")
				 public void the_Total_Price_of_bananas(Integer price) {
					assertEquals(price.intValue(),checkout.total());}
		    
		 // scanning_apple_and_banana
		    @Given("the price of {string} is {int}")
		       public void thePriceOfBananaa(String item, Integer price) {
			        this.price=price;}
		    @Given("the price of {string} is {int}")
		       public void thePriceOfapple(String item, Integer price) {
			        this.price=price;} 
		    
		    @When("i check {int} {string}")
			public void iCheckout_banana(Integer iteamCount, String string) {
				checkout = new najah.edu.checkout();
				checkout.add(iteamCount,price);}
		    @When("i check {int} {string}")
			public void iCheckout_apple(Integer iteamCount, String string) {
				checkout = new najah.edu.checkout();
				checkout.add(iteamCount,price);}
		    
		    @Then("the total price should be {int}")
			 public void the_Total_Price_of_banana_and_apple(Integer price) {
		    	checkout = new najah.edu.checkout();
				checkout.addtwo(p,price);}
				assertEquals(price.intValue(),checkout.total());}
		    
	}