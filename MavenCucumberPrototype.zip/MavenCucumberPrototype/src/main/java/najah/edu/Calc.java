package najah.edu;


public class Calc {


	public int and(Integer n1,Integer n2) {
	return n1+n2;
	}
}
