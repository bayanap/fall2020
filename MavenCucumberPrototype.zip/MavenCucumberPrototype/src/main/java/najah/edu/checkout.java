package najah.edu;

import java.util.Scanner;

public class checkout {
	private   static int totalBanana ,totalapple ;
	 private   static int totalacc  ;
static int tot ;
	
	public static void add(Integer itemnum, int price) { 
	 	totalacc = (itemnum.intValue()*price);
	 	tot = totalacc*2 ; //two bananas
		}
	 	
	public void addtwo(Integer itemnum, int price) {
		// TODO Auto-generated method stub
		totalapple = (itemnum.intValue()*price);
		totalBanana= (itemnum.intValue()*price);
	 	tot = totalBanana+totalapple ; // banana+apple

	}
		public static int   total() {
	 		return tot;
		}

}
